"""Pack with plugins for chats."""
