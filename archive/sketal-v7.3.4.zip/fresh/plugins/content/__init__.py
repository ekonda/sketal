"""Pack with plugins that can generate content or information."""
