"""Pack with plugins that are useful for controlling bot."""
