"""Pack with game plugins."""
