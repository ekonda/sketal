"""Pack with plugins that are controversial or uncategorized."""
