"""Pack with plugins that are useful for other plugins."""
